"""This is an example script to measure Noise Figure from the SSB Additive Phase Noise Plot on the FSWP.
The DUT is the LNA50.
The alias is 'fswp'
"""

# RsInstrument package is hosted on pypi.org
from RsInstrument import *
from tkinter import *
import time
import matplotlib.pyplot as plt
import numpy as np

# Initialize the session
fswp = RsInstrument('TCPIP::FSWP8-101402.local.::hislip0', reset=False)

fswp.write('*RST')
fswp.write_with_opc('*CLS') # Clear Status Register
fswp.write_with_opc('SYST:DISP:UPD ON') # Show Display
idn = fswp.query('*IDN?')
print(f"\nHello, I am: '{idn}'")
print(f'Instrument installed options: {",".join(fswp.instrument_options)}')

root = Tk()
myLabel = Label(root, text="Connect the Source Output and RF Input of the FSWP to the Amplifier Input and Output respectively")
myLabel.pack()

myButton = Button(root, text = "Okay!", command = root.destroy)
myButton.pack()
root.mainloop()

root = Tk()
myLabel2 = Label(root, text="Configure the power supply and connect it to the Amplifier's Bias Input")
myLabel2.pack()

myButton2 = Button(root, text = "Okay!", command = root.destroy)
myButton2.pack()
root.mainloop()
# Noise Figure Measurement Setup
fswp.write_with_opc('INIT:CONT OFF') # Single Sweep Mode
fswp.write_with_opc('DISP:WIND1:TRAC2:MODE BLAN') # Turn trace 2 off
fswp.write_with_opc('SENS:FREQ:STOP 100000000') # Stop Frequency of 100MHz
fswp.write_with_opc('CONF:PNO:MEAS RES') # Measure Residual Phase Noise
fswp.write_with_opc('SOUR:GEN:FREQ 150000000') # Start Frequency of 1.5GHz
fswp.write_with_opc('SOUR:GEN:FREQ:STEP 100000000') # Step Size of 100MHz
fswp.write_with_opc('SOUR:GEN:LEV -40') # Source Power of -40dBm
fswp.write_with_opc('SOUR:GEN:STAT ON') # Turn on the Source
fswp.write_with_opc('INP:ATT 10') # Set Input Attenuation to 10dB
fswp.write_with_opc('SENS:SWE:XFAC 100') # 100 cross correlations
fswp.write_with_opc('CALC:MARK1:STAT ON') # Turn on Marker 1
fswp.write_with_opc('CALC:MARK1:X 1e+6') # Put marker at 1MHz offset
fswp.write_with_opc('CALC:MARK:FUNC:NFIG:STAT ON') # Report Noise Figure at the marker position
fswp.write_with_opc('CALC:MARK:FUNC:NFIG:LEV -41') # Power entering the DUT accounting for cable loss

start = 1500000000 # Start Frequency of 1.5GHz
stop = 2500000000 # Stop Frequency of 2.5GHz
step = 100000000 # Step Size is 100MHz
nf_results = [] # Empty array for Noise Figure values

# Measure Noise Figure for a defined set of frequencies
for i in range(start,stop,step):
    fswp.write_with_opc(f'SOUR:GEN:FREQ {i}') # Set source frequency to the desired value
    fswp.write_with_opc('INIT:IMM')
    nf_results.append(fswp.query_with_opc('CALC1:MARK1:FUNC:NFIG:RES?')) # Query Noise Figure Marker Value


fswp.write_with_opc('SOUR:GEN:STAT OFF') # Turn off the Source
Frequencies = list(range(start,stop,step)) # Frequencies in a list.

plt.figure()
plt.plot(Frequencies, nf_results)
plt.xlabel("Frequency (Hz)")
plt.ylabel("Noise Figure (dB)")
plt.title("Noise Figure vs Frequency")

plt.show()
# Close the session
fswp.close()
